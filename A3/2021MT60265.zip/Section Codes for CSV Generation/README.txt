Shift codes to parent directory before running.
Along with code, confusion.py and take_input.py should also be shifted.

These codes are only for generation of csv in asked/best case. These codes require the folder data

Designed to be run by the a3.sh provided