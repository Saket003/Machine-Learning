Shift codes to parent directory before running.
Along with code, confusion.py and take_input.py should also be shifted.

These codes are only for timing and confusion matrices in report. They also require folder data.

Many of there are hard-codes and purely to get results for report.